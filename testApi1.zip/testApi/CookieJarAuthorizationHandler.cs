﻿namespace testApi
{
    internal class CookieJarAuthorizationHandler
    {
    }
}