﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using testApi.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace testApi.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class MigrantsController : ControllerBase
	{
		static HttpClient client = new HttpClient();

		// GET api/<Immigrants>/5
		[HttpGet("{id}")]
		public string Get(int id)
		{
			return "value";
		}

		[HttpGet]
		public async Task<List<Migrants>> GetAsync()
		{
			var url = "https://run.mocky.io/v3/7e5a63b8-0b58-49aa-8f87-a4f6cc53ed07";
			HttpResponseMessage response = await client.GetAsync(url);
			var result = new List<Migrants>();

			if (response.IsSuccessStatusCode)
			{
				result = await JsonSerializer.DeserializeAsync<List<Migrants>>(await response.Content.ReadAsStreamAsync());
			}
			return result;
		}
	}
}
